package com.ug14.rumahsakit;

import java.util.Scanner;

public class Dokter {
  
}
