package com.ug14.rumahsakit;

public class Pelayanan {
    public class Pelayanan {
        private int idPelayanan;
        private String nama;

        public void mengaturJadwal(Pasien pasien, Dokter dokter, Jadwal jadwal) {

        }

        public Pasien registrasi() {

            return null;
        };
    }
