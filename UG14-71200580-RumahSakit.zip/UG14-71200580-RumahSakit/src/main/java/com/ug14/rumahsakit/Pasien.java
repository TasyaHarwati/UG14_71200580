package com.ug14.rumahsakit;

public class Pasien {
    private int rm;
    private String nama;
    private int usia;
    private String alamat;
    private String penyakit;
    private int level_Penyakit;
    private Boolean status;

    public Pasien(int id_Pasien, String Nama_Pasien, int usia, String alamat, String penyakit, int level_Penyakit, boolean status){
        rm = id_Pasien
        nama = Nama_Pasien
        usia = usia
        alamat = alamat
        penyakit = penyakit
        level_Penyakit = level_Penyakit
    }


}
