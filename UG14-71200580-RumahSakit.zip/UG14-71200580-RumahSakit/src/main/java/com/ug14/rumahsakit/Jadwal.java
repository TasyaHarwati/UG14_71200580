package com.ug14.rumahsakit;

public class Jadwal {
    public class Jadwal {
        private int idPemeriksaan;
        private Pasien pasien;
        private Dokter dokter;
        private Suster suster;
        private Pelayanan pelayanan;
        private Boolean statusDaftar;
        private Boolean statusScreening;
    }
}
