package com.ug14.rumahsakit;

public class Suster {
    private int idSuster;
    private String nama;

    public Suster(int ID, String Nama){
        ID = idSuster;
        Nama = nama;
    }
    public screening(com.ug14.rumahsakit.Pasien){

    }
}
